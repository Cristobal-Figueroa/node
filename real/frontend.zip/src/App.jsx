import { useState, useEffect } from 'react'
import { Container, Typography, Box, TextField, Button, List, ListItem, ListItemText, ListItemSecondaryAction } from '@mui/material'
import { Edit as EditIcon, Delete as DeleteIcon } from '@mui/icons-material'
import IconButton from '@mui/material/IconButton'
import Dialog from '@mui/material/Dialog'
import DialogTitle from '@mui/material/DialogTitle'
import DialogContent from '@mui/material/DialogContent'
import DialogActions from '@mui/material/DialogActions'
import axios from 'axios'

const API_URL = 'http://localhost:5000/api'

function App() {
  const [items, setItems] = useState([])
  const [open, setOpen] = useState(false)
  const [selectedItem, setSelectedItem] = useState(null)
  const [formData, setFormData] = useState({
    name: '',
    description: ''
  })

  useEffect(() => {
    fetchItems()
  }, [])

  const fetchItems = async () => {
    try {
      const response = await axios.get(`${API_URL}/items`)
      setItems(response.data)
    } catch (error) {
      console.error('Error fetching items:', error)
    }
  }

  const handleOpen = (item = null) => {
    if (item) {
      setFormData({ name: item.name, description: item.description })
      setSelectedItem(item)
    } else {
      setFormData({ name: '', description: '' })
      setSelectedItem(null)
    }
    setOpen(true)
  }

  const handleClose = () => {
    setOpen(false)
    setFormData({ name: '', description: '' })
    setSelectedItem(null)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      if (selectedItem) {
        await axios.put(`${API_URL}/items/${selectedItem.id}`, formData)
      } else {
        await axios.post(`${API_URL}/items`, formData)
      }
      fetchItems()
      handleClose()
    } catch (error) {
      console.error('Error saving item:', error)
    }
  }

  const handleDelete = async (id) => {
    try {
      await axios.delete(`${API_URL}/items/${id}`)
      fetchItems()
    } catch (error) {
      console.error('Error deleting item:', error)
    }
  }

  return (
    <Container maxWidth="md">
      <Box sx={{ my: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          CRUD Application
        </Typography>
        <Button variant="contained" color="primary" onClick={() => handleOpen()}>
          Add New Item
        </Button>
        <List sx={{ mt: 2 }}>
          {items.map((item) => (
            <ListItem key={item.id}>
              <ListItemText
                primary={item.name}
                secondary={item.description}
              />
              <ListItemSecondaryAction>
                <IconButton edge="end" onClick={() => handleOpen(item)}>
                  <EditIcon />
                </IconButton>
                <IconButton edge="end" onClick={() => handleDelete(item.id)}>
                  <DeleteIcon />
                </IconButton>
              </ListItemSecondaryAction>
            </ListItem>
          ))}
        </List>
      </Box>

      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>{selectedItem ? 'Edit Item' : 'Add New Item'}</DialogTitle>
        <DialogContent>
          <Box component="form" onSubmit={handleSubmit} sx={{ mt: 2 }}>
            <TextField
              fullWidth
              label="Name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              margin="normal"
              required
            />
            <TextField
              fullWidth
              label="Description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              margin="normal"
              multiline
              rows={4}
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleSubmit} variant="contained" color="primary">
            {selectedItem ? 'Update' : 'Create'}
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  )
}

export default App
